
package pe.com.cibertec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import pe.com.cibertec.model.ProductoEntity;
import pe.com.cibertec.repository.ProductoRepository;

import java.util.List;
import java.util.Optional;

@Controller
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepository;

    @GetMapping("/registrarProductos")
    public String productos(Model model) {
        List<ProductoEntity> productos = productoRepository.findAll();
        model.addAttribute("productos", productos);
        return "registrarProductos";
    }

    @PostMapping("/guardarProducto")
    public String guardarProducto(@ModelAttribute ProductoEntity producto) {
        productoRepository.save(producto);
        return "redirect:/registrarProductos";
    }

    @GetMapping("/editarProducto/{id}")
    public String mostrarFormularioEditar(@PathVariable int id, Model model) {
        Optional<ProductoEntity> producto = productoRepository.findById(id);
        if (producto.isPresent()) {
            model.addAttribute("producto", producto.get());
            return "editarProducto";
        } else {
            return "redirect:/registrarProductos";
        }
    }

    @PostMapping("/editarProducto")
    public String editarProducto(@ModelAttribute ProductoEntity producto) {
        productoRepository.save(producto);
        return "redirect:/registrarProductos";
    }

    @PostMapping("/eliminarProducto")
    public String eliminarProducto(@RequestParam("productoId") int id) {
        productoRepository.deleteById(id);
        return "redirect:/registrarProductos";
    }
}
