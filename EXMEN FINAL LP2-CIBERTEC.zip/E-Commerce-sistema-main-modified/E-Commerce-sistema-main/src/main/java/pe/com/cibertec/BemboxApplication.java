package pe.com.cibertec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BemboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(BemboxApplication.class, args);
	}

}
