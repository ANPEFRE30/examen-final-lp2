package pe.com.cibertec.service;
import org.springframework.stereotype.Service;

@Service
public class SedeService {

}
